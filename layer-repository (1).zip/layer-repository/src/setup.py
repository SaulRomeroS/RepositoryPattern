from setuptools import setup

setup(
    name="users",
    version="0.1",
    packages=["users"],
)