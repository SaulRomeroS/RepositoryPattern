# Layer Application
Base project example demonstrating layer architecture.


Instructions for Unix-like systems
## Run

    source venv/bin/activate
    python src/app.py